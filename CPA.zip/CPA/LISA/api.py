import json
from watson_developer_cloud import AssistantV1

WORKSPACE_ID = 'bba8fdf5-881a-4ef9-8065-39f4e6a497d8'

def apiWatson(mensaje=""):
	assistant = AssistantV1(
	version='2018-09-20',
	username='eb38ac7e-413e-42b4-838e-88e379dac532',
	password='JNabFPeh4WsV',
	url='https://gateway.watsonplatform.net/assistant/api')

	response = assistant.message(
	    workspace_id= WORKSPACE_ID,
	    input = {'text': mensaje},
	).get_result()

	if response['output']['text']:
	  return str(response['output']['text'][0])