from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from django.http import HttpRequest
from django.views.decorators.csrf import csrf_exempt
from LISA.models import Chat, Mensaje
from django.utils import timezone
from datetime import datetime
from django.core.mail import send_mail
import json
from watson_developer_cloud import AssistantV1


WORKSPACE_ID = 'bba8fdf5-881a-4ef9-8065-39f4e6a497d8'
assistant = AssistantV1(
	version='2018-09-20',
	username='eb38ac7e-413e-42b4-838e-88e379dac532',
	password='JNabFPeh4WsV',
	url='https://gateway.watsonplatform.net/assistant/api')


mensajes_finales = ["Ya hemos terminado","Gracias por ponerte en contacto con nosotros"]
variables_contexto = ["nombre", "edad", "genero", "telefono", "ocupacion", "vinculacion", "vivienda", "ciudad"]

# Create your views here.

def  index(request):
	request.session['chat'] = []
	context_dict =  {}
	return render(request, 'LISA/index.html', context=context_dict)

def psicologos(request):
	return HttpResponse("Rango says here is about page.")

@csrf_exempt
def apiWatson(request=None):
	context = {}
	flagOptions = False
	final = False
	variables = []

	mensaje =  json.loads(request.body)
	try:
		if mensaje['context']:
			context = mensaje['context']
	except:
		pass

	response = assistant.message(
	    workspace_id= WORKSPACE_ID,
	    input = {'text': mensaje['input']['text']},
	    context = context,
	).get_result()

	#respuestas de LISA
	respuestaWatson = response["output"]["text"]
	for r in response["output"]["generic"]:
		if 'options' in r:
			for o in r['options']:
				respuestaWatson.append(o['label'])


	interaccion = {"mensaje":  mensaje['input']['text'], "respuesta": respuestaWatson , "fecha": datetime.now().strftime('%Y-%m-%dT%H:%M:%S.%f')}

	if 'chat' not in request.session or not request.session['chat']:
		request.session['chat'] = [interaccion]
	else:
		request.session['chat'].append(interaccion)
	request.session.modified = True  #set modified state
	

	for r in respuestaWatson:
		for m in mensajes_finales:
			if (m.lower() in r.lower()):
				final = True
				break
	
		

	#Si el usuario decide terminar
	if (("LISA, terminar").lower() in mensaje['input']['text'].lower()) or (final):
		
		for v in variables_contexto:
			try:
				variables.append(response["context"][v])
			except:
				if (v == "edad" or v == "telefono"):
					variables.append("0")
				else:
					variables.append("")
		print(variables)
		
		chat = Chat.objects.create(nombre=variables[0], edad=int(variables[1]),
			genero=variables[2], telefono=int(variables[3]), ocupacion=variables[4], 
			vinculacion=variables[5], vivienda=variables[6], ciudad=variables[7])

		for interacc in request.session['chat']:
			cuerpo = ""			
			if mensaje != '':
				Mensaje.objects.create(chat_id = chat, autor = variables[0], cuerpo= interacc["mensaje"], timestamp=datetime.now().strptime(interacc["fecha"],'%Y-%m-%dT%H:%M:%S.%f'))

			for respuesta in interacc["respuesta"]:
				cuerpo+=respuesta
			Mensaje.objects.create(chat_id = chat, autor = "watson", cuerpo= cuerpo,  timestamp=datetime.now().strptime(interacc["fecha"],'%Y-%m-%dT%H:%M:%S.%f'))
	
	return  HttpResponse(json.dumps(response), content_type="application/json")