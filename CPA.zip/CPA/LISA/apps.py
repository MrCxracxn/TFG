from django.apps import AppConfig


class LisaConfig(AppConfig):
    name = 'LISA'
