"""
    File name: apps.py
    Author: Junior Ivan Soler Saba
    Date created: 2019
    Date last modified: -
    Python Version: 3
"""

from django.apps import AppConfig


class LisaConfig(AppConfig):
    name = 'LISA'
