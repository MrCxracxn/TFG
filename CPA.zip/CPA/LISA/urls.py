"""
    File name: urls.py
    Author: Junior Ivan Soler Saba
    Date created: 2019
    Date last modified: -
    Python Version: 3
"""

from django.conf.urls import url
from LISA import views

urlpatterns = [ 
	url(r'^$', views.index, name='index'),
	url(r'^psicologos/', views.psicologos, name='psicologos'),
	url('apiWatson/', views.apiWatson, name='apiWatson'),
]