"""
    File name: models.py
    Author: Junior Ivan Soler Saba
    Date created: 2019
    Date last modified: -
    Python Version: 3
"""

from django.db import models
from django.contrib.auth.models import User
from django.conf import settings

class Chat(models.Model):
	chat_id = models.AutoField(primary_key=True, verbose_name="Id")
	psicologo = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, blank=True, null=True, verbose_name="Psicólog@")
	nombre = models.CharField(max_length=128)
	edad = models.IntegerField()
	genero =  models.CharField(max_length=128, verbose_name="Género")
	telefono = models.IntegerField(verbose_name="Teléfono")
	ocupacion = models.CharField(max_length=128, verbose_name="Ocupación")
	vinculacion = models.CharField(max_length=128, verbose_name="Vinculación")
	vivienda = models.CharField(max_length=128)
	ciudad = models.CharField(max_length=128)


	def __str__(self): # For Python 2, use __unicode__ too
		return str(self.chat_id)


	def formfield_for_foreignkey(self, db_field, request, **kwargs):
		if db_field.name == "psicologo":
			kwargs["queryset"] = User.objects.all()
		return super().formfield_for_foreignkey(db_field, request, **kwargs)

	def get_timestamp(self):
		for o in  list(Mensaje.objects.filter(chat_id=self.chat_id).filter().order_by('timestamp')):
			return o.timestamp
	def get_mensajes(self):
		return list(Mensaje.objects.filter(chat_id=self.chat_id).filter())



# Create your models here.
class Mensaje(models.Model):
	mensaje_id = models.AutoField(primary_key=True)
	chat_id = models.ForeignKey(Chat, on_delete=models.CASCADE)
	autor = models.CharField(max_length=128)
	timestamp = models.DateTimeField(null=True, blank=True)
	cuerpo = models.TextField()


	def __str__(self): # For Python 2, use __unicode__ too
		return str(self.mensaje_id)


