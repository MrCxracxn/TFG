from django.contrib import admin
from django.contrib.auth.models import Group
from LISA.models import Chat, Mensaje
import csv
from django.http import HttpResponse

class MensajeAdminInline(admin.TabularInline):
	model = Mensaje
	extra = 0
	can_delete = False

	readonly_fields = ['autor','cuerpo', 'timestamp']
	def has_add_permission(self, request, obj=None):
		return False

def export_csv(modeladmin, request, queryset):
	response = HttpResponse(content_type='text/csv')
	response['Content-Disposition'] = 'attachment; filename="Chat_fichero.csv"'
	output = []
	output.append(["[Nombre: "+queryset[0].nombre+"]","[Edad: "+str(queryset[0].edad)+"]",
		"[Género: "+queryset[0].genero+"]", "[Teléfono: "+str(queryset[0].telefono)+"]", 
		"[Ocupación: "+queryset[0].ocupacion+"]", "[Vinculación: "+queryset[0].vinculacion+"]", 
		"[Vivienda: "+queryset[0].vivienda+"]", "[Ciudad: "+queryset[0].ciudad+"]"])
	for q in queryset[0].get_mensajes():
		output.append(["["+str(q.timestamp)+"]", "[De: "+q.autor+"]", q.cuerpo])
		
	response.write(u'\ufeff'.encode('utf8'))
	writer = csv.writer(response)
	writer.writerows(output)
	return response
export_csv.short_description = "Descargar como CSV"

class ChatAdmin(admin.ModelAdmin):
	inlines = (MensajeAdminInline, )
	list_display = ['timestamp', 'psicologo']
	ordering = ["-chat_id"]
	actions = [export_csv]

	readonly_fields = ['chat_id', 'nombre', 'edad', 'genero', 'telefono', 'ocupacion', 'vinculacion', 'vivienda', 'ciudad']
	
	def timestamp(self,obj):
		return (obj.get_timestamp())
	def has_add_permission(self, request, obj=None):
		return False

	def get_queryset(self, request):
		qs = super(ChatAdmin, self).get_queryset(request)
		return qs if request.user.is_superuser else qs.filter(psicologo=request.user)
	
	
# Register your models here.
admin.site.register(Chat, ChatAdmin)


#TODO: comentar en la entrega
admin.site.unregister(Group)
